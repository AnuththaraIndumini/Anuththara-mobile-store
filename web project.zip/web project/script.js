function changeView(){


    var signIn = document.getElementById("signInBox");
    var signUp = document.getElementById("signUpBox");

    
    signIn.classList.toggle("d-none");
    signUp.classList.toggle("d-none");
}


function logIn(){
    window.location = "home.html";
}